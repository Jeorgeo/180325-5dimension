<?php

return $lang = array(
	"language"		=> "en",
	"description"	=> "Live Chat is an effective tool for increasing online e-commerce revenue. Answer incoming questions and proactively engage visitors in online chat — and get higher conversion rate! JivoSite live chat is simple and effective solution that boosts income without increasing the ad budget.",
	"title" 		=> "Just insert your widget ID here",
	"hint"			=> "Show hint"
);